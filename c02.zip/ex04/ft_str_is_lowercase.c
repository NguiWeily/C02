/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/25 19:00:57 by wngui             #+#    #+#             */
/*   Updated: 2023/06/25 19:08:22 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_lowercase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (!(str[i] >= 'a' && str[i] <= 'z'))
			return (0);
		i++;
	}
	return (1);
}
/*
#include <stdio.h>

int ft_str_is_lowercase(char *str);

int main(void)
{
    char str1[] = "hello";
    char str2[] = "Hello";
    char str3[] = "123";
    char str4[] = "";
    
    printf("%d\n", ft_str_is_lowercase(str1)); // Output: 1
    printf("%d\n", ft_str_is_lowercase(str2)); // Output: 0
    printf("%d\n", ft_str_is_lowercase(str3)); // Output: 0
    printf("%d\n", ft_str_is_lowercase(str4)); // Output: 1
    
    return 0;
}*/
