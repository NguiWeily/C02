/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/25 22:13:17 by wngui             #+#    #+#             */
/*   Updated: 2023/06/25 22:14:20 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_numeric(char *str)
{
	while (*str)
	{
		if (*str < '0' || *str > '9')
			return (0);
		str++;
	}
	return (1);
}
/*
int main() {
	char *str1 = "12345";
	char *str2 = "abc123";
	char *str3 = "";

	int result1 = ft_str_is_numeric(str1); // returns 1
	int result2 = ft_str_is_numeric(str2); // returns 0
	int result3 = ft_str_is_numeric(str3); // returns 1

	printf("Result 1: %d\n", result1);
	printf("Result 2: %d\n", result2);
	printf("Result 3: %d\n", result3);

	return 0;
}*/
