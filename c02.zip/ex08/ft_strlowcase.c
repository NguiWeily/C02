/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlowcase.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/25 19:52:46 by wngui             #+#    #+#             */
/*   Updated: 2023/06/25 19:56:47 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strlowcase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] >= 'A' && str[i] <= 'Z')
			str[i] += 32;
		i++;
	}
	return (str);
}
/*
#include <stdio.h>

char *ft_strlowcase(char *str);

int main(void)
{
    char str1[] = "Hello World!";
    char str2[] = "LOWERCASE";
    char str3[] = "Hello123";

    printf("%s\n", ft_strlowcase(str1)); // Output: hello world!
    printf("%s\n", ft_strlowcase(str2)); // Output: lowercase
    printf("%s\n", ft_strlowcase(str3)); // Output: hello123

    return 0;
}*/
