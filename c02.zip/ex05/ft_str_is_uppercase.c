/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/25 19:11:34 by wngui             #+#    #+#             */
/*   Updated: 2023/06/25 19:14:34 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
int	ft_str_is_uppercase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (!(str[i] >= 'A' && str[i] <= 'Z'))
			return (0);
		i++;
	}
	return (1);
}
/*
#include <stdio.h>

int ft_str_is_uppercase(char *str);

int main(void)
{
    char str1[] = "HELLO";
    char str2[] = "Hello";
    char str3[] = "123";
    char str4[] = "";
    
    printf("%d\n", ft_str_is_uppercase(str1)); // Output: 1
    printf("%d\n", ft_str_is_uppercase(str2)); // Output: 0
    printf("%d\n", ft_str_is_uppercase(str3)); // Output: 0
    printf("%d\n", ft_str_is_uppercase(str4)); // Output: 1
    
    return 0;
}*/
