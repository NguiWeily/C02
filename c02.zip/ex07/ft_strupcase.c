/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strupcase.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/25 19:45:44 by wngui             #+#    #+#             */
/*   Updated: 2023/06/25 19:51:39 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strupcase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] >= 'a' && str[i] <= 'z')
			str[i] -= 32;
		i++;
	}
	return (str);
}
/*
#include <stdio.h>

char *ft_strupcase(char *str);

int main(void)
{
    char str1[] = "Hello World!";
    char str2[] = "hello123";
    char str3[] = "UPPERCASE";
    
    printf("%s\n", ft_strupcase(str1)); // Output: HELLO WORLD!
    printf("%s\n", ft_strupcase(str2)); // Output: HELLO123
    printf("%s\n", ft_strupcase(str3)); // Output: UPPERCASE
    
    return 0;
}*/
