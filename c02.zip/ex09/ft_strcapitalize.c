/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/25 20:20:09 by wngui             #+#    #+#             */
/*   Updated: 2023/06/25 21:32:06 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
char	*ft_strlowcase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] >= 'A' && str[i] <= 'Z')
			str[i] += 32;
		i++;
	}
	return (str);
}

char	*ft_strcapitalize(char *str)
{
	int	i;
	int	change;

	i = 0;
	change = 1;
	ft_strlowcase(str);
	while (str[i] != '\0')
	{
		if (str[i] >= 'a' && str[i] <= 'z')
		{
			if (change == 1)
				str[i] -= 32;
			change = 0;
		}
		else if (str[i] >= '0' && str[i] <= '9')
			change = 0;
		else
			change = 1;
		i++;
	}
	return (str);
}
/*
#include <stdio.h>

char *ft_strcapitalize(char *str);

int main(void)
{
    char str[] = "salut, comment tu vas ? 42mots quarante-deux; cinquante+et+un";
    
    printf("%s\n", ft_strcapitalize(str));
    
    return 0;
}*/
